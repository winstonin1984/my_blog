from django.urls import path
from . import views

urlpatterns = [
    path('<int:blog_pk>', views.blog_detail, name='blog_detail'),
    path('type/<int:blog_type_pk>', views.blog_types, name='blog_type'),
    path('blog_login/blog_write', views.blog_write, name='blog_write'),
    path('blog_login/', views.blog_login, name='blog_login'),
]
