from django.core import exceptions
from django.db import models
from django.contrib.auth.models import User
from ckeditor_uploader.fields import RichTextUploadingField
from read_counter.models import ReadNumExpendMethod
from PIL import Image


# Create your models here.
class BlogType(models.Model):
    objects = models.Manager
    type_name = models.CharField(max_length=15)

    def __str__(self):
        return self.type_name


class Blog(models.Model, ReadNumExpendMethod):
    objects = models.Manager
    title = models.CharField(max_length=50)
    blog_image = models.ImageField(upload_to='upload/%Y/%m/%d/', blank=True)
    blog_type = models.ForeignKey(BlogType, on_delete=models.DO_NOTHING, related_name='blog_tp')
    blog_describe = models.CharField(max_length=250)
    blog_content = RichTextUploadingField()
    author = models.ForeignKey(User, on_delete=models.DO_NOTHING)
    created_time = models.DateTimeField(auto_now_add=True)
    last_updated_time = models.DateTimeField(auto_now_add=True)

    # get the read number date form the model ReadCount if the number exist
    # return the number if not exit return the zero in blog model.

    def __str__(self):
        return "<Blog: %s>" % self.title

    class Meta:
        ordering = ['-created_time']

    def save(self, *args, **kwargs):
        blog = super(Blog, self).save(*args, **kwargs)

        if self.blog_image:
            image = Image.open(self.blog_image)
            (x, y) = image.size
            new_x = 730
            new_y = 200
            resized_image = image.resize((new_x, new_y), Image.ANTIALIAS)
            resized_image.save(self.blog_image.path)
        return blog

