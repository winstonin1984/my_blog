"""
version-1.0
writing by: ling luning
"""
from django.contrib.contenttypes.models import ContentType
from django.shortcuts import render_to_response, get_object_or_404, redirect, render
from .models import Blog, BlogType
from django.http import HttpResponse, HttpResponseRedirect
from .forms import BlogPostForm
from django.contrib.auth.models import User
import markdown
from django.core.paginator import Paginator
from read_counter.models import ReadCount
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from PIL import Image


# Create your views here.


def blog_home(request):
    blogs_all_list = Blog.objects.all()
    paginator = Paginator(blogs_all_list, 7)
    page_num = request.GET.get('page', 1)
    page_of_blogs = paginator.get_page(page_num)
    current_page_num = page_of_blogs.number
    page_range = list(range(max(current_page_num - 2, 1), current_page_num)) + \
                 list(range(current_page_num, min(current_page_num + 2, paginator.num_pages) + 1))
    if page_range[0] - 1 >= 2:
        page_range.insert(0, '...')
    if paginator.num_pages - page_range[-1] >= 2:
        page_range.append('...')
    if page_range[0] != 1:
        page_range.insert(0, 1)
    if page_range[-1] != paginator.num_pages:
        page_range.append(paginator.num_pages)

    # get the blog types list

    context = {
        'blogs_all_list': page_of_blogs.object_list.all(),
        'blog_all': blogs_all_list,
        'page_of_blogs': page_of_blogs,
        'page_range': page_range,
        'blog_types': BlogType.objects.all(),
    }
    return render_to_response('index.html', context)


def blog_detail(request, blog_pk):
    blog = get_object_or_404(Blog, pk=blog_pk)
    blog.blog_content = markdown.markdown(
        blog.blog_content, extensions=[
            'markdown.extensions.extra',
            'markdown.extensions.codehilite', ]
    )

    # this part is a read counter, and i try to update it.
    if not request.COOKIES.get('blog_%s_read' % blog_pk):
        ct = ContentType.objects.get_for_model(Blog)
        if ReadCount.objects.filter(content_type=ct, object_id=blog.pk).count():
            readnum = ReadCount.objects.get(content_type=ct, object_id=blog.pk)
        else:
            readnum = ReadCount(content_type=ct, object_id=blog.pk)
        readnum.read_num += 1
        readnum.save()
    context = {'blog': blog,
               'previous_blog': Blog.objects.filter(created_time__gt=blog.created_time).last(),
               'next_blog': Blog.objects.filter(created_time__lt=blog.created_time).first(),

               }
    response = render_to_response('blog_detail.html', context)
    response.set_cookie('blog_%s_read' % blog_pk, 'true', max_age=300)
    return response


def blog_types(request, blog_type_pk):
    blog_type = get_object_or_404(BlogType, pk=blog_type_pk)
    blog_type_list = Blog.objects.filter(blog_type=blog_type)
    paginator = Paginator(blog_type_list, 7)
    page_num = request.GET.get('page', 1)
    page_of_blogs = paginator.get_page(page_num)
    current_page_num = page_of_blogs.number
    page_range = list(range(max(current_page_num - 2, 1), current_page_num)) + \
                 list(range(current_page_num, min(current_page_num + 2, paginator.num_pages) + 1))
    if page_range[0] - 1 >= 2:
        page_range.insert(0, '...')
    if paginator.num_pages - page_range[-1] >= 2:
        page_range.append('...')
    if page_range[0] != 1:
        page_range.insert(0, 1)
    if page_range[-1] != paginator.num_pages:
        page_range.append(paginator.num_pages)
    page_of_blogs = paginator.get_page(page_num)
    context = {'blogs': page_of_blogs.object_list.all(),
               'blog_nums': blog_type_list.all(),
               'blog_type': blog_type,
               'page_of_blogs': page_of_blogs,
               'page_range': page_range,
               'blog_types': BlogType.objects.all(),
               'blog_dates': Blog.objects.dates('created_time', 'month', order="DESC")}
    return render_to_response('blog_type.html', context)


# this part is not work very well so I comment it and i will refine it in the future
@login_required  # 一个登录页面的装饰器， 只有登录成功了以后 才可以访问这个页面
def blog_write(request):
    if request.method == "POST":
        print("the POST method")
        blog_post_form = BlogPostForm(data=request.POST)
        if blog_post_form.is_valid():
            new_blog = blog_post_form.save(commit=False)
            new_blog.author = User.objects.get(id=1)
            new_blog.save()

            return redirect("/")
        else:
            return HttpResponse("Illegal POST, Please write it again")

    else:
        blog_post_form = BlogPostForm()
        context = {'blog_post_form': blog_post_form,
                   'blog_types': BlogType.objects.all(), }
        return render(request, 'blog_write.html', context)


def blog_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            return HttpResponseRedirect('blog_write')
        else:
            context = {'login_err': 'Please recheck your username or password !'}
            return render(request, 'blog_login.html', context)
    return render(request, 'blog_login.html')
