from django import forms
from .models import Blog


class BlogPostForm(forms.ModelForm):
    class Meta:
        model = Blog
        fields = ('title', 'blog_type', 'blog_image', 'blog_describe', 'blog_content')
