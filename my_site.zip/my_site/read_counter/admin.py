from django.contrib import admin
from .models import ReadCount


# Register your models here.
@admin.register(ReadCount)
class ReadCountAdmin(admin.ModelAdmin):
    list_display = ('read_num', 'content_object')


