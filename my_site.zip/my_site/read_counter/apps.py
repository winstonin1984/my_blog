from django.apps import AppConfig


class ReadCounterConfig(AppConfig):
    name = 'read_counter'
